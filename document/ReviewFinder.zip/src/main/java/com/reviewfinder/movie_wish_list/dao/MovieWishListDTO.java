package com.reviewfinder.movie_wish_list.dao;

public class MovieWishListDTO {
	private String userid;
	private int movie_num;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getMovie_num() {
		return movie_num;
	}
	public void setMovie_num(int movie_num) {
		this.movie_num = movie_num;
	}
	
	
}
