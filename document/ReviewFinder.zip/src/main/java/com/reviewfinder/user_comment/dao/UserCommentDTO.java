package com.reviewfinder.user_comment.dao;

public class UserCommentDTO {
	private String userid;
	private int comment_num;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getComment_num() {
		return comment_num;
	}
	public void setComment_num(int comment_num) {
		this.comment_num = comment_num;
	}
	
	
}
